---
title: "Ed McCann"
tags: 
- people
---
# Ed McCann

Ed McCann is the current president of the [Institution of Civil Engineers](notes/Institution%20of%20Civil%20Engineers.md); the 157th to hold the post.

His main aim for his tenure as ICE president is to promote increased productivity, through the terms "efficiency" and "effectiveness".

📝 More can be found in his [2021 ICE Presidential Address Notes](notes/2021%20ICE%20Presidential%20Address%20Notes.md).






