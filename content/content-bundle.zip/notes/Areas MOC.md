---
title: "Areas MOC"
tags: 
- map-of-content
---
# Areas

![Areas MOC](/content/attachments/hans-luiggi-uvQmacxnfcE-unsplash.jpg)
I have many different interests, from music to hot-air ballooning! This page is a directory of some of the topics which may interest civil engineers, or those who are interested in technology and productivity.

 - 📖 [[Book Summaries]]
 - ✅ [[Productivity]]
 - 🧠 [Personal Knowledge Management](notes/Personal%20Knowledge%20Management.md)
 - 🎵 [[Music]]
 - 💸 [Finance](notes/Finance.md)
 - 💻 [Web Development](notes/Web%20Development.md)
 


