---
title: "Factor of safety for slopes (temporary and permanent)"
tags: 
- slopes
- temporary-works
---
# Factor of safety for slopes (temporary and permanent)

In [N. A. Trenter](notes/N.%20A.%20Trenter.md)'s book 'Earthworks - A Guide (2001)', the following factors of safety have been derived. This has come from a combination of [[BS 6031 2009]] and scientific research.

![Table 13.3](attachments/Pasted%20image%2020220616144926.png)








