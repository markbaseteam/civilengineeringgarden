---
title: "Design MOC"
tags: 
- map-of-content
---

![CAD Design](content/notes/images/Design%20MOC-1655366980630.png)
# Design MOC
I started completing civil engineering design work as part of a [[Temporary Works]] design team. I am slowly gathering new methods and ways of solving problems, which I will share here for future reference. Below are a set of methods in different areas.

## Geotechnics
[[Calculate bearing capacity of soils]]
[Factor of safety for slopes (temporary and permanent)](notes/Factor%20of%20safety%20for%20slopes%20(temporary%20and%20permanent).md)
[Converting track load to an equivalent line load](notes/Converting%20track%20load%20to%20an%20equivalent%20line%20load.md)
## Steel

## Concrete

## Actions on Structures










