---
title: "Personal Knowledge Management"
tags: #definition
---

# Personal Knowledge Management (PKM)
A personal knowledge management system is a system by which you enter information and past experience in order to free up mental space. By documenting and recording knowledge, you can refer back to it at a later date without needing to keep it at the forefront of your mind.

Keeping a PKM system can be a time-consuming but ultimately worthwhile task. There is no "right way" to store your information; pen-and-paper can be used, or a more dedicated software such as my favourite, [[Obsidian]].











Navigation: [Homepage](_index), [Civil Engineering MOC](notes/Civil%20Engineering%20MOC/Civil%20Engineering%20MOC.md)
