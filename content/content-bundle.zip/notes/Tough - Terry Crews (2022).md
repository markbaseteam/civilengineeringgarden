---
title: "Tough - Terry Crews (2022)"
tags: 
- book
---
# Tough
## [[Terry Crews]]
## 2022
URL: [Goodreads](https://www.goodreads.com/search?qid=&q=9780593329818)
##### Status:: #Finished
##### Rating:: 2.5
###### Genres: [[Self-Improvement]], [[Discipline]], [[Family]]
###### #content/book 

![image|100](https://books.google.com/books/content?id=cqw5EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api)

# Mental Model
---
MM:: Terry Crews recounts his life from being a young, abused boy watching his parents be either alcoholics or being pressured into a Christian cult, going through the NFL into his acting career and draws life lessons to give to the reader. His story is remarkable, and reflections on being black in america hit hard. I think I found that he got successful, learnt his inner power, but maybe missed on actionable things or specific ways in which he helped people. I think it was a good story of his life but not sure I came out with much more than I went in with.