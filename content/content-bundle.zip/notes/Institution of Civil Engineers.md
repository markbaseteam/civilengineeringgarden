---
title: "Institution of Civil Engineers"
tags: 
- ice
---
# Institution of Civil Engineers
The [Institution of Civil Engineers](notes/Institution%20of%20Civil%20Engineers.md) is the leading professional engineering body and charitable body for civil engineering. 

👨‍💼 **Current President** - [Ed McCann](People/Ed%20McCann.md)










