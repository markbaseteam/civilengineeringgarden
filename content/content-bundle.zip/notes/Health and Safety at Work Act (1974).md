---
title: "Health and Safety at Work Act (1974)"
tags: 
- 
---
# Health and Safety at Work Act (1974)
The [Health and Safety at Work Act (1974)](notes/Health%20and%20Safety%20at%20Work%20Act%20(1974).md) is a primary piece of legislation covering occupational health and safety in Great Britain. The act is a form of umbrella which oversees multiple other pieces of legislation within it.

Some other acts and pieces of legislation are:

 - [Lifting Operations and Lifting Equipment Regulations (LOLER) (1998)](notes/Lifting%20Operations%20and%20Lifting%20Equipment%20Regulations%20(LOLER)%20(1998).md)
 - [Provision and Use of Work Equipment Regulations (PUWER) (1998)](notes/Provision%20and%20Use%20of%20Work%20Equipment%20Regulations%20(PUWER)%20(1998).md)
 - [[The Work at Height Regulations (2005)]]
 - [[Avoiding Danger from Overhead Power Lines (GS6) (2013)]]
 - [Manual Handling Operations Regulations (MHOR) (1992)](notes/Manual%20Handling%20Operations%20Regulations%20(MHOR)%20(1992).md)
 - [Personal Protective Equipment at Work Regulations (PPE) (2022)](notes/Personal%20Protective%20Equipment%20at%20Work%20Regulations%20(PPE)%20(2022).md)








