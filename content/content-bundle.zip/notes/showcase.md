---
title: "Showcase"
---

Want to see what Quartz can do? Here are some cool community gardens :)

- [Quartz Documentation (this site!)](https://quartz.jzhao.xyz/)
- [Jacky Zhao's Garden](https://garden.jzhao.xyz/)
- [AWAGMI Intern Notes](https://notes.awagmi.xyz/)
- [Shihyu's PKM](https://shihyuho.github.io/pkm/)
- [Chloe's Garden](https://garden.chloeabrasada.online/)
- [SlRvb's Site](https://slrvb.github.io/Site/)
- [Course notes for Information Technology Advanced Theory](https://a2itnotes.github.io/quartz/)
- [Brandon Boswell's Garden](https://brandonkboswell.com)
- [Siyang's Courtyard](https://siyangsun.github.io/courtyard/)

If you want to see your own on here, submit a [Pull Request adding yourself to this file](https://github.com/jackyzha0/quartz/blob/hugo/content/notes/showcase.md)!
