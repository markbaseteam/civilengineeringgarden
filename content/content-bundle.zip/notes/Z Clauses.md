---
title: "Z Clauses"
tags: 
- commercial
---
# Z Clauses
Z Clauses are a key part of the contract which can change and alter the way the contract functions. Z clauses have the power to rewrite or overwrite portions of the standard [Contract](notes/Civil%20Engineering%20MOC/Commercial%20MOC/Contract.md). These can act as a way to negotiate and reallocate [[risk]] into a contract in order for it to be more feasible for one or another party.












Navigation: [Homepage](_index.md), [Civil Engineering MOC](notes/Civil%20Engineering%20MOC/Civil%20Engineering%20MOC.md), [Areas MOC](Areas%20MOC)
