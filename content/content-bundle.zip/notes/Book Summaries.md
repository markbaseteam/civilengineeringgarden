---
title: "Book Summaries"
tags: 
- books
- summaries
---
# Book Summaries / Reflections
As part of tending my own [Digital Garden](notes/Digital%20Garden.md), whenever I read a book I summarise it, try and get some actionable points from it and keep it for future reference. 

## 2022
 - [Kaizen - Sarah Harvey (2020)](notes/Kaizen%20-%20Sarah%20Harvey%20(2020).md)
 - [Wabi Sabi - Beth Kempton (2018)](notes/Wabi%20Sabi%20-%20Beth%20Kempton%20(2018).md)
 - [Taste - Stanley Tucci (2021)](notes/Taste%20-%20Stanley%20Tucci%20(2021).md)
 - [Tough - Terry Crews (2022)](notes/Tough%20-%20Terry%20Crews%20(2022).md)
 - [How to be Perfect - Mike Schur (2022)](notes/How%20to%20be%20Perfect%20-%20Mike%20Schur%20(2022).md)
 - [Four Thousand Weeks - Oliver Burkeman (2021)](notes/Four%20Thousand%20Weeks%20-%20Oliver%20Burkeman%20(2021).md)









