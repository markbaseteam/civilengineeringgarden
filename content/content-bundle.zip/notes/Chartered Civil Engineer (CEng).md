---
title: "Chartered Civil Engineer (CEng)"
tags: 
- cpd
- ice
---
# Chartered Civil Engineer (CEng)
A Chartered Member of the [[Institution of Civil Engineers]] is an individual who has shown the ability and gained sufficient experience to be recognsied as at the top of their field. 

As per the [ICE website](https://www.ice.org.uk/careers-learning/professional-qualification-support/how-to-become-a-professionally-qualified-civil-engineer/):

>Chartered engineers need to be highly qualified in their fields.

>The title CEng is protected by law, as is the title chartered civil engineer, and is one of the most recognisable international engineering qualifications.

>This means that the educational requirements are demanding.







