---
title: "Sustainability MOC"
tags: 
- map-of-content
- sustainability
---
# Sustainability MOC

![](attachments/appolinary-kalashnikova-WYGhTLym344-unsplash%20(1).png)
Sustainability within [Civil Engineering](notes/Civil%20Engineering%20MOC/Civil%20Engineering%20MOC.md) is an ever-evolving topic, with new innovations and legislation guiding the industry to embrace sustainability.






